# Chunk 09 — integrate and audit the hardware package

## Progress from Chunk 08

The mechanical drawings are assembled with the native KiCad schematic, PCB outline starter, project-local symbol library, key/matrix map, and both BOM exports. A CAD audit checks solid validity, the 320 × 120 × 18 mm envelope, key and switch counts, contact containment on the board, and parts outside the case.

This creates a reviewable cross-tool handoff; it does not add physical model features. KiCad’s PCB is an outline starter with no placed footprints or routed copper, and the electrical design still needs an ERC review before fabrication.

## Resulting model and audit

The cumulative work-stage model remains at 204 FreeCAD objects. The separately grouped final assembly file contains 210 tree objects, including groups, and its audit reports 203 valid physical solids. The audit checks modeled geometry only; it does not simulate key travel, switch timing, or assembly tolerances.

## FreeCAD and reports

- [Chunk-stage FreeCAD model](work_packages/CHUNK_09/MetroKey25_Chunk_09.FCStd)
- [Grouped final FreeCAD assembly](work_packages/CHUNK_09/MetroKey25_Final_Assembly.FCStd)
- [Final assembly STEP](work_packages/CHUNK_09/MetroKey25_Final_Assembly.step)
- [CAD geometry audit](work_packages/CHUNK_09/CAD_Geometry_Audit.csv)
- [CAD component manifest](work_packages/CHUNK_09/CAD_Component_Manifest.csv)
- [Project BOM estimate](work_packages/CHUNK_09/BOM.csv)
- [Integrated handoff notes](work_packages/CHUNK_09/Integrated_Hardware_Handoff.md)
- [Stage preview](work_packages/CHUNK_09/preview.svg)

## Native KiCad project files

- [KiCad project](work_packages/CHUNK_09/KiCad_Project/MetroKey25.kicad_pro)
- [Schematic](work_packages/CHUNK_09/KiCad_Project/MetroKey25.kicad_sch)
- [PCB outline starter](work_packages/CHUNK_09/KiCad_Project/MetroKey25.kicad_pcb)
- [Project-local controller symbol library](work_packages/CHUNK_09/KiCad_Project/MetroKey25.kicad_sym)
- [Symbol library table](work_packages/CHUNK_09/KiCad_Project/sym-lib-table) and [footprint library table](work_packages/CHUNK_09/KiCad_Project/fp-lib-table)
- [Project-specific BOM](work_packages/CHUNK_09/KiCad_Project/MetroKey25_KiCad_BOM.csv) and [full BOM](work_packages/CHUNK_09/KiCad_Project/MetroKey25_Full_BOM.csv)
- [Key matrix map](work_packages/CHUNK_09/KiCad_Project/key_matrix_map.csv)
- [KiCad package notes](work_packages/CHUNK_09/KiCad_Project/README.md)
- [Version-control ignore rules](work_packages/CHUNK_09/KiCad_Project/.gitignore)
- [Parent package notes](work_packages/CHUNK_09/README.md)

![Integrated CAD and KiCad handoff](work_packages/CHUNK_09/preview.svg)

**Next change:** Chunk 10 records the key orientation correction and the shared KiCad/FreeCAD coordinate transform; the corrected piano direction has also been propagated through these staged snapshots.
