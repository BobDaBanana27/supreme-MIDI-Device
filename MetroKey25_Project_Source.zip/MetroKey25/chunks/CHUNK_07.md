# Chunk 07 — prepare separate fabrication exports

## Progress from Chunk 06

Chunk 06 completed the mechanical solids. This package converts that model into usable neutral files: printable key families and chassis/action STL files, STEP versions of the major subassemblies, and a complete STEP assembly. The component manifest records the 203 physical solids by name, group, bounds, volume, and geometry validity.

The key geometry in these exports uses the corrected piano layout. No new physical solids are added here; this is an export and measurement stage, which is why its FreeCAD object count remains 204.

## Files produced

- [Cumulative FreeCAD model](work_packages/CHUNK_07/MetroKey25_Chunk_07.FCStd)
- [Part-family export map and preview](work_packages/CHUNK_07/Part_Family_Export_Map.svg)
- [Complete assembly STEP](work_packages/CHUNK_07/MetroKey25_Assembly.step)
- [Chassis STEP](work_packages/CHUNK_07/MetroKey25_Chassis.step) and [chassis STL](work_packages/CHUNK_07/MetroKey25_Chassis.stl)
- [Key-action STEP](work_packages/CHUNK_07/MetroKey25_Key_Action.step) and [key-action STL](work_packages/CHUNK_07/MetroKey25_Key_Action.stl)
- [Electronics placement STEP](work_packages/CHUNK_07/MetroKey25_Electronics_Placement.step)
- [White keycaps STL](work_packages/CHUNK_07/MetroKey25_White_Keycaps.stl)
- [Black keycaps STL](work_packages/CHUNK_07/MetroKey25_Black_Keycaps.stl)
- [Combined 25-key keycap-set STL](work_packages/CHUNK_07/MetroKey25_Keycap_Set.stl)
- [CAD component manifest](work_packages/CHUNK_07/CAD_Component_Manifest.csv)
- [Stage preview](work_packages/CHUNK_07/preview.svg)
- [Package notes](work_packages/CHUNK_07/README.md)

![Part families, assembly export, and measured component record](work_packages/CHUNK_07/preview.svg)

**Next change:** Chunk 08 creates an integrated drawing set that communicates the completed geometry and switch coordinates.

The combined keycap-set STL contains 15 white and 10 black shells in keyboard layout. The black shells are raised 0.2 mm from the white-key tops in this combined export to prevent coincident faces; the separate white and black STLs retain their exact individual model positions.
