# Chunk 10 — correct the key orientation and align the CAD tools

## Progress from Chunk 09

A visual review against a real 25-key mini MIDI controller identified that the black-key groups needed to sit at the rear of the white-key field. The corrected key placement was moved into all saved FreeCAD snapshots from chunks 02–09 and carried through keybed drawings and fabrication exports, so the earlier stages no longer show the rejected direction.

The same integration pass maps the KiCad board outline to the FreeCAD matrix-board frame with Y_FreeCAD = 120 − Y_KiCad. X coordinates match directly. This makes the same 304 × 69 mm board envelope reviewable in both applications.

## Resulting files

- [Editable corrected FreeCAD integration assembly](work_packages/CHUNK_10/MetroKey25_Integration.FCStd)
- [White keycaps STL](work_packages/CHUNK_10/exports/MetroKey25_White_Keycaps.stl)
- [Black keycaps STL](work_packages/CHUNK_10/exports/MetroKey25_Black_Keycaps.stl)
- [Combined 25-key keycap-set STL](work_packages/CHUNK_10/exports/MetroKey25_Keycap_Set.stl)
- [Keycap export validation notes](work_packages/CHUNK_10/Keycap_STL_Validation.md)
- [Corrected keybed pitch map](work_packages/CHUNK_10/drawings/Keybed_Pitch_Map.csv)
- [Dimensioned keybed drawing](work_packages/CHUNK_10/drawings/Dimensioned_Keybed.svg)
- [KiCad / FreeCAD shared-envelope drawing](work_packages/CHUNK_10/drawings/KiCad_FreeCAD_Envelope.svg)
- [Shared XY mapping and component manifest](work_packages/CHUNK_10/Shared_XY_Alignment.csv)
- [KiCad 10 project snapshot](work_packages/CHUNK_10/KiCad_Project/MetroKey25.kicad_pro)
- [Correction verification notes](work_packages/CHUNK_10/Correction_Verification.md)
- [Stage preview](work_packages/CHUNK_10/preview.svg)

![KiCad and FreeCAD coordinate frame and corrected key direction](work_packages/CHUNK_10/preview.svg)

The commercial product is a visual reference for normal piano-key orientation, not a dimension or parts source. The current CAD and KiCad files remain design-stage; they do not claim a physical prototype or production-ready PCB.

The combined keycap-set STL contains all 25 shells in keyboard layout. The black-key shells are separated from the white-key tops by 0.2 mm in this combined mesh to prevent coincident faces; the separate white and black STL files preserve each cap's exact individual model position.
