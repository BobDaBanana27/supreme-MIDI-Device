# Chunk 05 — integrate controls, controller, and USB-C

## Progress from Chunk 04

The scan board now gets its rear interface: octave-down, octave-up, and mode/function buttons; an RP2040-Zero module envelope; and a USB-C connector aligned to the case opening. A control/GPIO table records how those physical controls reach the selected controller pins.

The new drawing focuses on the rear connection and module placement while the cumulative model keeps the entire keybed and 50-switch scan assembly in view.

## Resulting model

The cumulative FreeCAD snapshot contains 194 objects: the 189-object scan-board assembly plus three buttons, one controller envelope, and one connector.

## Files produced

- [Cumulative FreeCAD model](work_packages/CHUNK_05/MetroKey25_Chunk_05.FCStd)
- [Stage preview](work_packages/CHUNK_05/preview.svg)
- [Rear control, module, and connector drawing](work_packages/CHUNK_05/Rear_Control_Integration.svg)
- [Control and GPIO assignment table](work_packages/CHUNK_05/Control_Module_Map.csv)
- [Package notes](work_packages/CHUNK_05/README.md)

![Rear controls, RP2040-Zero envelope, and USB-C alignment](work_packages/CHUNK_05/preview.svg)

**Next change:** Chunk 06 adds the supports and strain relief needed to locate the board and connector within the case.
