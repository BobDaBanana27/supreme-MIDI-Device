# Chunk 03 — model the two-contact key action

## Progress from Chunk 02

The 25-note layout is now given a proposed key action. Each cap gets a pivot seat and pin, then two separate follower bodies below it. A and B followers represent sequential electrical contacts: the first contact should trigger before the second as the key travels down.

This is a mechanical concept rather than a calibrated velocity mechanism. The follower spacing and contact travel still need a physical trial with the selected switches and membrane geometry.

## Resulting model

The cumulative FreeCAD snapshot contains 138 objects: 37 from the case/keybed plus 25 seats, 25 pins, and 50 contact followers. The corrected black-key orientation carries forward.

## Files produced

- [Cumulative FreeCAD model](work_packages/CHUNK_03/MetroKey25_Chunk_03.FCStd)
- [Stage preview](work_packages/CHUNK_03/preview.svg)
- [Two-contact key-action cutaway](work_packages/CHUNK_03/Key_Action_Cutaway.svg)
- [Package notes](work_packages/CHUNK_03/README.md)

![Pivot seats, pins, and sequential A/B followers](work_packages/CHUNK_03/preview.svg)

**Next change:** Chunk 04 adds the scan board and the 50 physical switch bodies under these followers.
