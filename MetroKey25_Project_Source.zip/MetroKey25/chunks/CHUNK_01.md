# Chunk 1 — complete enclosure shell and control deck

## Work package

Build the whole enclosure foundation as one CAD pass: the 320 × 120 × 18 mm shell floor and perimeter, centered rear USB-C opening, full key-window bezel, and bored three-button rear deck. This groups the related enclosure geometry that was previously split across several tiny steps.

## Files produced

- [Editable cumulative FreeCAD model](work_packages/CHUNK_01/MetroKey25_Chunk_01.FCStd)
- [CAD preview](work_packages/CHUNK_01/preview.svg)
- [Dimensioned housing drawing](work_packages/CHUNK_01/Housing_Dimensions.svg)
- [Package notes](work_packages/CHUNK_01/README.md)

![Complete chassis and deck](work_packages/CHUNK_01/preview.svg)

