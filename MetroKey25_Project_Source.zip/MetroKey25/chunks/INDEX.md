# MetroKey 25 — staged design work

The numbered chunks are file-backed design packages, not hour claims. Chunks 01–06 add physical model features; 07–09 turn that model into manufacturing exports, drawings, and a native KiCad handoff; 10 reconciles the key orientation and coordinate frames. Each package page records the concrete change from the prior stage and inventories its deliverables.

## Work progression

- [Detailed progression and stage-by-stage deltas](PROGRESSION.md)
- [Machine-readable progression table](PROGRESSION.csv)
- [01 — enclosure foundation](CHUNK_01.md) · 12 model objects · [preview](work_packages/CHUNK_01/preview.svg)
- [02 — 25-note keybed and pitch layout](CHUNK_02.md) · 37 objects · [corrected keybed preview](work_packages/CHUNK_02/preview.svg)
- [03 — 25 pivots and 50 dual-contact followers](CHUNK_03.md) · 138 objects · [action cutaway](work_packages/CHUNK_03/preview.svg)
- [04 — scan PCB and 50 physical switch bodies](CHUNK_04.md) · 189 objects · [switch-placement preview](work_packages/CHUNK_04/preview.svg)
- [05 — controls, controller module, and USB-C](CHUNK_05.md) · 194 objects · [rear-interface preview](work_packages/CHUNK_05/preview.svg)
- [06 — mounts, board supports, and strain relief](CHUNK_06.md) · 204 objects · [mounting detail](work_packages/CHUNK_06/preview.svg)
- [07 — fabrication exports and solid manifest](CHUNK_07.md) · no new solids · [export map](work_packages/CHUNK_07/preview.svg)
- [08 — integrated, dimensioned drawing set](CHUNK_08.md) · no new solids · [integrated switch/keybed preview](work_packages/CHUNK_08/preview.svg)
- [09 — native KiCad + CAD integration and audit](CHUNK_09.md) · no new solids · [handoff preview](work_packages/CHUNK_09/preview.svg)
- [10 — orientation correction and shared XY frame](CHUNK_10.md) · correction propagated through staged models · [cross-tool drawing](work_packages/CHUNK_10/drawings/KiCad_FreeCAD_Envelope.svg)

## Package file inventories

Each package page records its stage change and links its key artifacts; package-level notes document additional files. The main application entrypoints are also listed here:

- [FreeCAD cumulative snapshots, STEP/STL exports, and reports](../hardware/CAD/MetroKey25/README.md)
- [KiCad project entrypoints and library notes](../hardware/KiCad/MetroKey25/README.md)
- [Chunk 09 native KiCad project snapshot](work_packages/CHUNK_09/KiCad_Project/README.md)
- [Chunk 10 aligned KiCad project snapshot](work_packages/CHUNK_10/KiCad_Project/README.md)

The FreeCAD snapshots for chunks 02–09 now all carry the same corrected piano orientation: black keys sit at the rear edge and the white keys extend toward the player. Chunks 07–09 are intentionally file-production stages, so their mechanical object count stays at 204 while their exports, drawings, KiCad handoff, and audit accumulate. The current orientation is supported by the [OMNITRONIC KEY-25 product reference](https://www.steinigke.de/en/mpn11045074-omnitronic-key-25-midi-controller.html). The previews are digital drawings, not photos of a physical prototype.

