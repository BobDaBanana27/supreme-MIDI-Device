# Chunk 05 — controls and USB-C integration

**Change from Chunk 04:** add octave/mode buttons, the RP2040-Zero module envelope, and the USB-C connector in the rear control region.

**Cumulative model:** 194 objects: the 189-object scan-board assembly plus three controls, one controller module, and one connector.

**Files added:** `MetroKey25_Chunk_05.FCStd`, `Control_Module_Map.csv`, and `Rear_Control_Integration.svg`.

![Rear controls and USB-C integration](preview.svg)

**Next:** add board supports, case bosses, connector strain relief, and the BOM in Chunk 06.