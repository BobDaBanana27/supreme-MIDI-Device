# MetroKey 25 - KiCad project

Open `MetroKey25.kicad_pro` in KiCad 10. The project directory contains the schematic, PCB outline, local symbol library and tables, key-to-matrix map, and BOMs. The `sym-lib-table` resolves the RP2040-Zero symbol with a `${KIPRJMOD}` relative path, so the project does not depend on a library elsewhere on this computer.

## Project files

- `MetroKey25.kicad_pro` - KiCad project entrypoint.
- `MetroKey25.kicad_sch` - editable electrical schematic for the 50 switch contacts, 50 isolation diodes, RP2040-Zero module pins, and three control buttons.
- `MetroKey25.kicad_sym` and `sym-lib-table` - project-local RP2040-Zero module symbol and its library lookup table.
- `MetroKey25.kicad_pcb` - 304 x 69 mm Edge.Cuts outline matching the matrix-board envelope in the FreeCAD model.
- `fp-lib-table` - project-local footprint table; no footprint library is assigned yet.
- `key_matrix_map.csv` - MIDI note-to-contact and matrix row/column assignment.
- `MetroKey25_KiCad_BOM.csv` - estimated capture-level component list.
- `MetroKey25_Full_BOM.csv` - project-level cost estimate.

The PCB file is deliberately a mechanical outline starter: it has no footprints, assigned nets, or routed copper. Select and measure the switch, diode, and module mounting footprints before laying out copper or manufacturing the board. The schematic and board are separate handoff artifacts and are not yet connected by assigned footprints or a completed netlist/layout flow.

The `.gitignore` excludes per-user KiCad session settings (`*.kicad_prl`), automatic project backups, and autosave files. Keep those editor-state files out of a shared project copy.
