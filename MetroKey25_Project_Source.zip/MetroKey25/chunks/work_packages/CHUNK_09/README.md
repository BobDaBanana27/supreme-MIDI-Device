# Chunk 09 — KiCad and CAD integration

**Change from Chunk 08:** collect the mechanical model with a native KiCad project, matrix and BOM data, and a geometry audit in one handoff package.

**Mechanical model:** the work-stage snapshot is 204 FreeCAD objects. The grouped MetroKey25_Final_Assembly.FCStd is 210 tree objects because it includes assembly groups; the audit counts 203 valid physical solids. All ten black keys remain in the corrected rearward position.

**KiCad files:** the folder includes .kicad_pro, .kicad_sch, .kicad_pcb, .kicad_sym, symbol and footprint library tables, two BOM CSVs, the key-matrix map, and this package README.

**Electrical scope:** the schematic and PCB are editable KiCad starter files. The PCB currently has an outline only; footprints, assigned nets, routing, and ERC validation remain future engineering work.

![Integrated package preview](preview.svg)
