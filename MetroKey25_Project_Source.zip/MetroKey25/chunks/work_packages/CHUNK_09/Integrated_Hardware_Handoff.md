# MetroKey 25 integrated hardware package

This review package brings together the cumulative mechanical CAD model, switch-coordinate data, KiCad project, and costed component list. The geometry audit passes the modeled 320 × 120 × 18 mm envelope, key/switch counts, board bounds, and solid-validity checks. It does not establish key motion, switch actuation, collision-free travel, manufacturing tolerance, or physical fit.

## Native design files

- `MetroKey25_Final_Assembly.FCStd` — editable full mechanical model.
- `MetroKey25_Final_Assembly.step` — neutral full-assembly export.
- `KiCad_Project/MetroKey25.kicad_pro` — editable KiCad project snapshot with schematic, outline board, local symbol, BOM, and key map.
- `CAD_Geometry_Audit.csv` — measured CAD checks and limits.
- `CAD_Component_Manifest.csv` — individual component bounds, volume, group, and model validity.
- `BOM.csv` — project parts estimate.

The KiCad board is still a perimeter-only starter. Its schematic and electrical design need a KiCad ERC pass and footprint selection before fabrication. No firmware or physical prototype is included.
