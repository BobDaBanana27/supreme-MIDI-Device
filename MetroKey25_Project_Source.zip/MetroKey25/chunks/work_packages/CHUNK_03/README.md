# Chunk 03 — two-contact key action

**Change from Chunk 02:** add a pivot seat and pin for each of the 25 keys and 50 actuator followers for the sequential A/B contacts.

**Cumulative model:** 138 objects: case, corrected 25-key bed, 25 pivots, 25 pins, and 50 followers. The black keys retain the corrected rearward Y position.

**Files added:** `MetroKey25_Chunk_03.FCStd` and `Key_Action_Cutaway.svg`.

![Two-contact action cutaway](preview.svg)

**Next:** add the matrix carrier and all 50 switch bodies in Chunk 04.