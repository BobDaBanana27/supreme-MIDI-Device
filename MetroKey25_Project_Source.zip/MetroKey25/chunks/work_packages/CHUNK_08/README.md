# Chunk 08 — integrated mechanical drawings

**Change from Chunk 07:** keep the 204-object mechanical assembly and produce a review set that ties the enclosure, corrected keybed, switch layout, and assembly layers together.

**Progression within the drawings:** the Chunk 04 switch sheet showed only board contacts. This package replaces that view with an integrated drawing overlaying all 50 A/B switch centers and scan rows on the chassis and full 25-key layout. Separate sheets show the dimensioned enclosure and exploded assembly order.

**Files added:** Dimensioned_Top_View.svg, integrated Switch_Placement_Drawing.svg, Exploded_Assembly.svg, and the stage preview.

![Integrated key/switch drawing](preview.svg)

These are CAD drawings, not photographs of a physical build.
