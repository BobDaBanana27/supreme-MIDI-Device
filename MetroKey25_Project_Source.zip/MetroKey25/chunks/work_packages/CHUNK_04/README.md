# Chunk 04 — scan board and switch placement

**Change from Chunk 03:** add the MatrixPCB and place 50 switch bodies beneath the two actuation points on each note. Tie each position to the five-row by ten-column matrix.

**Cumulative model:** 189 objects; key direction and pitch locations carry forward unchanged.

**Files added:** `MetroKey25_Chunk_04.FCStd`, `PCB_Switch_Placement.csv`, `key_matrix_map.csv`, and `Switch_Placement_Drawing.svg`.

![50-contact switch placement](preview.svg)

**Next:** add the rear controls, module envelope, and USB-C alignment in Chunk 05.