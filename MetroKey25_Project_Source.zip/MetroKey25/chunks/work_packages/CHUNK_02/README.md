# Chunk 02 — 25-note keybed

**Change from Chunk 01:** add 15 white and 10 black keycaps in C3–C5 pitch order and assign every cap its MIDI note and physical X/Y position.

**Cumulative model:** 37 objects: 12 case parts plus 25 keycaps. All ten black caps now use rearward Y=36–82 mm; white keys span Y=8–82 mm. The map and native model use the same correction.

**Files added:** `MetroKey25_Chunk_02.FCStd`, `Keybed_Pitch_Layout.csv`, and `Dimensioned_Keybed.svg`.

![Corrected C3–C5 keybed](preview.svg)

**Next:** add the two-contact pivot and follower action in Chunk 03.