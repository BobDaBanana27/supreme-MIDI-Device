# Chunk 06 — supported mechanical assembly

**Change from Chunk 05:** add four hollow case bosses, four PCB support posts, and two USB strain-relief cheeks; place the estimated BOM beside the assembly.

**Cumulative model:** 204 objects. This is the final mechanical geometry stage before export and documentation work.

**Files added:** `MetroKey25_Chunk_06.FCStd`, `BOM.csv`, and `Mounting_Detail.svg`.

![Board supports and mounting detail](preview.svg)

**Next:** export the part families and measured component manifest in Chunk 07.