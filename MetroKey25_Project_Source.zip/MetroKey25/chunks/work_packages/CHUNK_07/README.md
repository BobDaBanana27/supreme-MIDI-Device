# Chunk 07 — manufacturing export package

**Change from Chunk 06:** preserve the 204-object cumulative model and export the enclosure, key families, key-action assembly, electronics envelope, and full assembly to neutral formats. The manifest records bounds, volumes, and geometry status for 203 physical solids.

**Orientation:** all ten black-key caps in the model and exports use the corrected rearward piano arrangement.

**Files added:** assembly STEP; chassis STEP/STL; key-action STEP/STL; electronics placement STEP; white, black, and combined keycap-set STL; part-family SVG; component manifest.

The separate white-key file contains 15 shells and the black-key file contains 10. The combined `MetroKey25_Keycap_Set.stl` contains all 25 keycaps in keyboard layout. Its black-key shells have a 0.2 mm vertical clearance above the white-key tops to avoid coincident faces in the combined mesh; use the separate color STLs for the exact individual key geometry.

![Export family map](preview.svg)

The exports are design-stage geometry. Validate fit, travel, tolerances, and materials before fabrication.
