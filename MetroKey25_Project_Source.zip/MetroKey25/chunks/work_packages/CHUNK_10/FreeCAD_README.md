# MetroKey 25 - FreeCAD assembly

Open `MetroKey25_Assembly.FCStd` in FreeCAD 1.1. It is the editable assembly entrypoint and contains 203 individually named solids for the 320 x 120 x 18 mm enclosure, 25 correctly oriented piano keys (black keys occupy y=36..82 mm toward the rear controls), the two-contact action, 50 switch bodies, rear controls, RP2040-Zero and USB-C envelopes, and mounting hardware. The assembly tree is organized into six groups: chassis and enclosure, key caps, key action, matrix board and switches, rear I/O, and mounting hardware. The root records revision A and millimetre units.

![MetroKey 25 assembly overview](drawings/Assembly_Drawing.svg)

## Application files

- `MetroKey25_Assembly.FCStd` - native FreeCAD assembly document.
- `exports/` - full assembly STEP, part-family STEP files, and separate STL exports for print-fit experiments.
- `drawings/` - assembly, dimensioned, exploded, key-action, control, mounting, switch-placement, and KiCad/FreeCAD shared-envelope SVG drawings.
- `reports/` - component manifest, geometry audit, and build-status notes.
- `../../../chunks/INDEX.md` - ten cumulative design packages with their own FreeCAD snapshots and visual previews.

## Coordinate convention and key direction

The FreeCAD chassis origin is at the front-left. Y increases toward the rear controls: the white keys span Y=8–82 mm and the black keys span Y=36–82 mm. That puts the shorter black keys in the rear half of the white-key field. In the KiCad board project, the outline is X=8–312, Y=4–73 mm and maps to FreeCAD with `Y_FreeCAD = 120 − Y_KiCad`; see the shared-envelope drawing.
The STEP files are neutral geometry exports; the STL files are tessellated print-fit models. The separate part-family exports are useful for inspection and prototyping. Use the native assembly for selecting and editing individual component solids.

This is an early mechanical fit model, not a fabrication release. The RP2040-Zero is represented by a module envelope. Key travel, contact timing, switch and module footprints, tolerances, material, and clearances need measurement and prototype validation. The 18 mm shell height does not include the cable bend or key travel above the body.
