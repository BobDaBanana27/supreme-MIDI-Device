# Keycap STL export check

These exports were regenerated from `MetroKey25_Integration.FCStd` using FreeCAD 1.1.4.

| File | Contents | Mesh check |
|---|---|---|
| `exports/MetroKey25_White_Keycaps.stl` | 15 white-key shells | 180 triangles; closed shells; no degenerate facets |
| `exports/MetroKey25_Black_Keycaps.stl` | 10 black-key shells in the corrected rear position | 120 triangles; closed shells; no degenerate facets |
| `exports/MetroKey25_Keycap_Set.stl` | All 25 keycaps in the keyboard layout | 25 separate closed shells; 300 triangles; no degenerate facets |

In the combined set only, black-key shells are shifted upward by 0.2 mm (Z=16.8–18.2 mm) so their bottoms do not coincide with the white-key top faces (Z=16.6 mm). This export-only clearance avoids coplanar contact faces in a multi-shell STL. The separate white and black files preserve the exact key positions from the integration model. The FreeCAD source geometry is unchanged.

The STL geometry remains a design-stage fit model; it is not a fabrication release.
