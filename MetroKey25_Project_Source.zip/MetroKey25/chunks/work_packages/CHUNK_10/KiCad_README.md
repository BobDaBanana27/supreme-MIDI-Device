# MetroKey 25 - KiCad project

Open `MetroKey25.kicad_pro` in KiCad 10. The project directory contains the schematic, PCB outline, local symbol library and tables, key-to-matrix map, and BOMs. The `sym-lib-table` resolves the RP2040-Zero symbol with a `${KIPRJMOD}` relative path, so the project does not depend on a library elsewhere on this computer.

## Project files

- `MetroKey25.kicad_pro` - KiCad project entrypoint.
- `MetroKey25.kicad_sch` - editable electrical schematic for the 50 switch contacts, 50 isolation diodes, RP2040-Zero module pins, and three control buttons.
- `MetroKey25.kicad_sym` and `sym-lib-table` - project-local RP2040-Zero module symbol and its library lookup table.
- `MetroKey25.kicad_pcb` - 304 x 69 mm Edge.Cuts outline at KiCad x=8..312, y=4..73 mm. It matches the FreeCAD board bounds x=8..312, y=47..116 mm using the documented Y-axis conversion Y_FreeCAD = 120 − Y_KiCad.
- `fp-lib-table` - project-local footprint table; no footprint library is assigned yet.
- `key_matrix_map.csv` - MIDI note-to-contact and matrix row/column assignment.
- `MetroKey25_KiCad_BOM.csv` - estimated capture-level component list.
- `MetroKey25_Full_BOM.csv` - project-level cost estimate.

## Mechanical coordinate conversion

The FreeCAD chassis frame uses Y=0 at the front and Y=120 mm at the rear. KiCad's default board-editor axis display increases Y downward; the Origins & Axes preference can change its display convention. This board uses X=8–312, Y=4–73 mm so its physical outline maps to the FreeCAD matrix board at X=8–312, Y=47–116 mm with `Y_FreeCAD = 120 − Y_KiCad`. See the [shared-envelope drawing](../../../hardware/CAD/MetroKey25/drawings/KiCad_FreeCAD_Envelope.svg) and [KiCad PCB Editor documentation](https://docs.kicad.org/10.0/en/pcbnew/pcbnew.html).
The PCB file is deliberately a mechanical outline starter: it has no footprints, assigned nets, or routed copper. Select and measure the switch, diode, and module mounting footprints before laying out copper or manufacturing the board. The schematic and board are separate handoff artifacts and are not yet connected by assigned footprints or a completed netlist/layout flow.

The `.gitignore` excludes per-user KiCad session settings (`*.kicad_prl`), automatic project backups, and autosave files. Keep those editor-state files out of a shared project copy.

