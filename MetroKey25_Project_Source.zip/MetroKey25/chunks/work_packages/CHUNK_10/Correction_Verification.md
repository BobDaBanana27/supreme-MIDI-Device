# Key orientation and cross-tool alignment verification

## Mechanical correction

The ten black key caps were shifted 28 mm toward the rear control deck in the native FreeCAD assembly. Their final Y bounds are 36–82 mm. The 15 white keys remain in the frontward field, Y=8–82 mm. Their shared back edge lets the shorter black keys occupy the rear half of the white-key field, as on a piano keyboard. Each black cap remains over its two-contact action region.

The pitch map, dimensioned keybed view, component manifest, FreeCAD assembly, full assembly STEP, black-key STEP/STL, and combined 25-key STL all use the corrected positions. The separately linked product example is an ordinary 25-key velocity-sensitive MIDI controller used as a visual layout reference: [OMNITRONIC KEY-25 MIDI Controller](https://www.steinigke.de/en/mpn11045074-omnitronic-key-25-midi-controller.html).

**FreeCAD-load verification:** each corrected `.FCStd` was opened and saved through FreeCAD 1.1.4, then reopened. All 10 black-key objects in the Chunk 02–09 snapshots, Chunk 09 grouped final assembly, Chunk 10 integration model, and main project assembly load with a 28 mm Y placement and world Y bounds of 36–82 mm. The regenerated black-key STEP contains 10 solids with those bounds; the full assembly STEP contains 203 solids in the 320 × 120 × 18 mm envelope.

## Shared KiCad / FreeCAD frame

The chassis is 320×120 mm. FreeCAD places MatrixPCB at X=8–312, Y=47–116 mm. KiCad uses its conventional positive-down Y direction, so the 304×69 mm Edge.Cuts rectangle is X=8–312, Y=4–73 mm; use `Y_FreeCAD = 120 − Y_KiCad` to map the physical outline. X coordinates match directly. `Shared_XY_Alignment.csv` and `drawings/KiCad_FreeCAD_Envelope.svg` record the conversion and rearward key orientation.

## Opening and scope

- Open `MetroKey25_Integration.FCStd` in FreeCAD 1.1 or newer.
- Open `KiCad_Project/MetroKey25.kicad_pro` in KiCad 10.
- The KiCad PCB remains an outline starter: no footprints, assigned nets, or routed copper are included.
- This package verifies modeled coordinates and exported handoff files; it does not claim that physical key motion, velocity response, tolerances, or assembly have been tested.
