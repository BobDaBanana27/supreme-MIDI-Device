# Work package 10 — orientation correction and shared coordinate frame

This integration pass checks the normal 25-key piano layout against the real 25-key OMNITRONIC KEY-25 product reference, corrects the black-key placement, and aligns the KiCad Edge.Cuts outline with the FreeCAD board envelope.

The corrected rearward key placement is propagated into every saved Chunk 02–09 FreeCAD snapshot and its key-facing drawing/export. The shared frame uses Y_FreeCAD = 120 − Y_KiCad; the PCB remains an outline starter, not a routed design.

## Main model and review files

- MetroKey25_Integration.FCStd — corrected FreeCAD model.
- preview.svg — cross-tool drawing preview.
- Correction_Verification.md — key-direction and coordinate review notes.
- Shared_XY_Alignment.csv — KiCad/FreeCAD board coordinate mapping.
- CAD_Component_Manifest.csv — solid and group bounds.

## Drawings and pitch map

- drawings/Assembly_Drawing.svg
- drawings/Dimensioned_Keybed.svg
- drawings/Keybed_Pitch_Map.csv
- drawings/KiCad_FreeCAD_Envelope.svg

## Fabrication exports

- exports/MetroKey25_Black_Keycaps.step
- exports/MetroKey25_Black_Keycaps.stl
- exports/MetroKey25_White_Keycaps.stl
- exports/MetroKey25_Integration.step
- exports/MetroKey25_Keycap_Set.stl
- Keycap_STL_Validation.md — exported component counts, mesh checks, and the combined-set clearance note.

The combined keycap-set STL contains all 25 caps in keyboard layout. Its black-key shells are lifted 0.2 mm above the white-key tops to avoid coincident mesh faces; the separate white and black STLs retain the exact individual model positions.

## KiCad project snapshot

- KiCad_Project/MetroKey25.kicad_pro
- KiCad_Project/MetroKey25.kicad_sch
- KiCad_Project/MetroKey25.kicad_pcb
- KiCad_Project/MetroKey25.kicad_sym
- KiCad_Project/sym-lib-table
- KiCad_Project/fp-lib-table
- KiCad_Project/key_matrix_map.csv
- KiCad_Project/MetroKey25_KiCad_BOM.csv
- KiCad_Project/MetroKey25_Full_BOM.csv
- KiCad_Project/README.md
- KiCad_Project/.gitignore

## Application notes

- FreeCAD_README.md
- KiCad_README.md

![Shared KiCad and FreeCAD envelope](preview.svg)

The commercial product is a visual reference for normal piano-key orientation, not a dimension or parts source. The current CAD and KiCad files remain design-stage; they do not claim a physical prototype or production-ready PCB.
