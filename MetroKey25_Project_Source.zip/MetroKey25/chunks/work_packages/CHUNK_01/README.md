# Chunk 01 — enclosure foundation

**Change from prior state:** start the mechanical project with the case, rear control deck, key window, and USB-C opening.

**Cumulative model:** 12 named case solids; no keycaps, key action, scan board, or switches yet.

**Files added:** `MetroKey25_Chunk_01.FCStd`, `Housing_Dimensions.svg`, `preview.svg`.

![Enclosure foundation](preview.svg)

**Next:** add the complete 25-key C3–C5 bed and its pitch map in Chunk 02.