# Chunk 04 — place the scan PCB and all 50 switches

## Progress from Chunk 03

The two-contact mechanism is connected to an electrical layout. Add one MatrixPCB carrier and place two switch bodies under every key. Assign every A/B contact a unique net and a row/column coordinate in the five-row by ten-column scan matrix.

This stage adds both physical and electrical evidence: FreeCAD solids show where switches fit; CSV maps let a reviewer trace a pitch to both contacts and its scan address.

## Resulting model

The cumulative FreeCAD snapshot contains 189 objects: Chunk 03’s 138 plus one board and 50 switches. The CSV placement table contains 50 contact centers and matches the 25-key pitch map.

## Files produced

- [Cumulative FreeCAD model](work_packages/CHUNK_04/MetroKey25_Chunk_04.FCStd)
- [Stage preview](work_packages/CHUNK_04/preview.svg)
- [Switch placement drawing](work_packages/CHUNK_04/Switch_Placement_Drawing.svg)
- [50-contact physical switch-center table](work_packages/CHUNK_04/PCB_Switch_Placement.csv)
- [Note-to-row/column/net map](work_packages/CHUNK_04/key_matrix_map.csv)
- [Package notes](work_packages/CHUNK_04/README.md)

![50 switch positions and scan-matrix placement](work_packages/CHUNK_04/preview.svg)

**Next change:** Chunk 05 integrates the controls, controller module, and USB-C opening with this matrix layout.
