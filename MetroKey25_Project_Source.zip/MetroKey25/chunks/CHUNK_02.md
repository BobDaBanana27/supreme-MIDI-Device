# Chunk 02 — build the complete 25-note keybed

## Progress from Chunk 01

The enclosure shell now receives the full two-octave key set: 15 white keys and 10 black keys, mapped in pitch order from MIDI 48 (C3) through MIDI 72 (C5). The corrected top view puts black-key groups at the rear, with the white keys extending toward the player, matching the normal orientation shown on a real compact MIDI keyboard.

The key map, native model, and drawing share the same 25 X positions and key widths. This creates the fixed pitch layout that the later pivots, followers, and switch coordinates attach to.

## Resulting model

The cumulative FreeCAD snapshot contains 37 objects: Chunk 01’s 12 enclosure objects plus 25 keycaps. The rearward black-key placement is present in this snapshot and remains corrected in every later snapshot.

## Files produced

- [Cumulative FreeCAD model](work_packages/CHUNK_02/MetroKey25_Chunk_02.FCStd)
- [Corrected keybed preview](work_packages/CHUNK_02/preview.svg)
- [Dimensioned keybed drawing](work_packages/CHUNK_02/Dimensioned_Keybed.svg)
- [25-note MIDI pitch and coordinate table](work_packages/CHUNK_02/Keybed_Pitch_Layout.csv)
- [Package notes](work_packages/CHUNK_02/README.md)

![Corrected 25-note piano keybed, rear at top and player at bottom](work_packages/CHUNK_02/preview.svg)

**Next change:** Chunk 03 adds the per-key pivots, pins, and sequential A/B contact followers to this exact key layout.
