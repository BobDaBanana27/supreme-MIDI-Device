# MetroKey 25 hardware project index

Start from the native project file for the application you want to use. Both project folders are self-contained and use relative paths for their local libraries.

## KiCad 10

- Open [`MetroKey25.kicad_pro`](KiCad/MetroKey25/MetroKey25.kicad_pro) in KiCad.
- Edit the electrical design in [`MetroKey25.kicad_sch`](KiCad/MetroKey25/MetroKey25.kicad_sch); the project-local RP2040-Zero symbol is in the same folder.
- The [`PCB document`](KiCad/MetroKey25/MetroKey25.kicad_pcb) currently contains a 304 x 69 mm Edge.Cuts outline at KiCad x=8..312, y=4..73 mm, mapped to the FreeCAD matrix-board bounds x=8..312, y=47..116 mm with Y_FreeCAD = 120 − Y_KiCad. It is an outline starter, with no footprints, assigned nets, or routed copper.
- The [`key matrix map`](KiCad/MetroKey25/key_matrix_map.csv) and the two BOMs are beside the KiCad project file.
- Read the [KiCad project notes](KiCad/MetroKey25/README.md) for scope and current handoff status.

## FreeCAD 1.1

- Open the editable [`MetroKey25_Assembly.FCStd`](CAD/MetroKey25/MetroKey25_Assembly.FCStd) assembly.
- The model tree is grouped by chassis, keys, key action, matrix board, rear I/O, and mounting hardware. Solids are individually named so groups can be shown, hidden, selected, and exported by family.
- See the [assembly drawing and CAD notes](CAD/MetroKey25/README.md), [STEP/STL exports](CAD/MetroKey25/exports/), [SVG drawings](CAD/MetroKey25/drawings/), and [geometry reports](CAD/MetroKey25/reports/).
- Cumulative snapshots and previews of the ten design packages are listed in the [progress index](../chunks/INDEX.md).

The CAD is a fit and packaging concept. It is not a fabrication release: the switch/contact geometry, clearances, tolerances, key travel, PCB footprints, and physical build still need engineering validation.
